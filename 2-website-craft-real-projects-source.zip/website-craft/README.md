# Website Craft: existing-project edition

Primary examples: Sky Grid portfolio, Aquilix preview14, Black Archive navigation. See skills/website-craft/references/real-projects.md for exact links, observations and limits. The invented studies are not included in this revised package. Original websites and older release archives remain unchanged.

Use skills/website-craft/SKILL.md with its relative references/assets/patterns. The bundle is plain Markdown/assets, not an installed plugin. Existing website content/media/source are not redistributed here. Original skill text/code retains MIT; bundled assets retain notices. No general browser, production or portability certification.
