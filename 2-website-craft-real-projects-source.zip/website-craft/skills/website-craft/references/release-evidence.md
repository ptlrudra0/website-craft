# Release evidence

Keep the evidence small enough to inspect and precise enough to reproduce.

## Declare the boundary

List what is real, illustrative and unconnected. State which browsers/devices were actually tested, whether a server was involved, where data is stored and whether any third party received it. Record checks as passed, failed, untested or blocked. A planned check is not a pass.

## Minimum evidence for the selected scope

- Screenshots of complete desktop and phone journeys, not only hero crops.
- A click/keyboard test of every primary action and its recovery path.
- Current local and external destinations checked through their actual owning source.
- Image load, intended crop, text wrap, overflow, focus, reduced-motion and empty/error states.
- Content/rights ledger for every bundled media/font family.
- Basic performance measurements with conditions stated, not a fabricated score.
- A public deployment readback when deployment is part of the request.

Automated checks and image inspection catch different errors. Use both. Fix found issues, regenerate evidence and label any remaining untested areas.

## Agent portability is a separate experiment

Documentation saying a host accepts a SKILL.md file is evidence of a potential installation route, not proof this workflow runs correctly there.

A native compatibility test must record the client name/version, model when available, install location, exact brief, permissions/network limitations, produced files, execution result and inspected output. Do not install or execute unrelated external skills as a shortcut. Do not spend credits without authority. A chat-only test cannot claim code execution or browser checks it did not perform.

Separate installation success, instruction-following, code execution, browser validation and final output quality. Test more than one brief/direction before generalizing. Keep authored reference products distinct from model-produced test artifacts. A fair competitor comparison uses the same brief, resources and review rules; popularity is not measured output quality.

Report tested clients individually. An untested host stays untested even when its file format appears compatible.
