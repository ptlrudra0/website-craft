# Build a product, not a screenshot

A strong opening viewport can still belong to an unfinished site. Judge the experience at the end of a visitor's task, not just at the top of the page.

## Choose a real scope

State which product you are building: an editorial site, service site, portfolio, catalogue, store, booking flow or application. Define one primary visitor and the task they must finish. A landing page is enough only when its primary job truly ends there. Do not add pages merely to increase page count.

Write a journey table before choosing components:

| Visitor question | Content or evidence needed | Next action | Failure or uncertainty |
| --- | --- | --- | --- |
| Is this relevant to me? | Specific offer and audience | Explore a relevant option | Offer unclear or not applicable |
| What exactly do I get? | Actual product/service detail | Choose, compare or inspect | Missing facts remain visibly unconfirmed |
| Can I trust it? | Real evidence, identity and policies | Review details | No invented clients, ratings or certification |
| What happens next? | Honest delivery/contact/checkout route | Complete the main task | Clear empty, error, pending and success states |
| Can I change my mind? | Edit, back, remove, cancel or undo | Recover without losing context | No dead-end completion screen |

Adapt this table to the product. A reading site needs find/read/save behavior, not an enquiry basket by habit.

## Inventory content before padding the design

List actual headlines, descriptions, product attributes, media roles, policies, destinations and form fields. Mark each as provided, verified, authored proposal or missing. Keep a missing fact out of published claims. A complete fictional specimen can use explicit example data, but that is not evidence of a real business or a production backend.

Avoid using giant spacing, repeated slogans or generic FAQ copy to hide a thin content model. Do not fill the gap with fake social proof.

## Make one world across different surfaces

Carry typography, colour, image lighting, shape, voice and motion across navigation, product detail, forms, overlays, error states and footer. The same world can have varied compositions. Do not copy the hero layout into every section.

Build at least one asset family with specific roles: hero, close-up, contextual, instructional, icon/mark. A collection of unrelated attractive images is not a family. Give meaningful images a job and inspect their crops at each layout. A farm photo does not prove a fictional farm's practices; a conceptual dashboard does not become a real product screenshot.

## Finish states, not only controls

For every visible control, define and implement its intended outcome. Ask which states apply:
- Default, hover, focus, press, selected and disabled.
- Empty, loading, error, partial, success and saved.
- Add, edit, remove, back, close, retry, cancel and undo.
- First visit, return visit and unavailable persistence.

Do not implement unnecessary states just to tick a list. If an operation has no server, do not pretend it sent, reserved or purchased anything. Local prototypes must say where data lives and what has not happened. Prefer a useful local action to a deceptive inert form.

Keep DOM updates safe. Use text nodes for user-entered content, validate stored data before rendering it and do not write arbitrary text with innerHTML. Collect no personal details merely to make a specimen feel realistic.

## Product-level review

Test the complete primary journey with real clicks and keyboard input. Refresh and return. Try an empty list, invalid input, a closed menu, a removed item and a failed operation. Inspect the content beyond the hero, including the last screen, footer and narrowest supported layout.

Compare against a strong reference at the same scale: whole product versus whole product, state versus state, phone versus phone. Record what is weaker, then fix the highest-impact gap. More examples or decorative motion do not compensate for an incomplete task.

A product can be visually complete while its real-world operation remains a prototype. Report both separately. Do not call a local planner a live ordering system, or an authored specimen a successful independent agent run.
