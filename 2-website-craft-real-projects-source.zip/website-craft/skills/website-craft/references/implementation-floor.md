# Implementation floor

Use the requested stack. These are observable behaviors, not a demand for a framework or a large dependency tree. Reuse the project's tested components where they exist. Read patterns/local-draft.js for a small dependency-free persistence and export kernel; adapt schema and controls to the actual product.

## Forms

- Every input has a visible associated label; placeholders are examples, not labels. Explain purpose and storage before collecting data.
- Use native type, required, min/max and length limits first. Trim required text so whitespace cannot pass. Associate field errors with aria-describedby, set aria-invalid, and move focus to the first invalid field after submit.
- Do not hide errors behind a transient toast alone. Preserve entered values on a failed operation. A successful local draft is not a successful send.
- Clear custom validity as the field is edited. A corrected field must not retain an old browser error.
- Do not collect personal contact details in a fictional demonstration merely to make it look real.

## Filters and lists

- Use buttons with aria-pressed for toggle filters, or labelled native controls. Keep the current selection visible beyond colour alone.
- Count the shown and total results, announce concise changes through a live status, and supply a no-results route back to all items.
- Hidden items must leave the keyboard tab order. Decide what happens when editing an item changes whether it matches the current filter; preserve focus on a meaningful visible control.
- Removal, reset, fixture load and saved-copy replacement need cancel or undo when they discard work. A blocking native alert is not a substitute for a considered flow.

## Local drafts and review

- Validate a versioned schema and bounded strings/arrays before rendering stored/imported state. Recognise stale or corrupt state rather than throwing away an unreported error.
- Put user text into textContent or input values, never arbitrary HTML. Treat saved text as untrusted on every return.
- Prepared previews, copy text and downloads must correspond to the current input. Invalidate or regenerate immediately after edits, removal, filter-related edits and external state changes.
- Save status must reflect the actual write result. When storage fails, offer an actual on-page download before navigation. Local storage is not backup or a security guarantee.
- Cross-tab changes must not silently overwrite unsaved work. Offer an explicit saved-copy choice and preserve an undo snapshot where useful.
- An async copy/export completion belongs to the revision that started it. Ignore stale success/error callbacks after edits, regeneration or a newer request. Test delayed resolve and reject, not only immediate success.
- Clipboard can fail or be absent. Keep selectable prepared text and a downloadable file as alternatives. Read back a real copied/exported payload in tests.

## Responsive images

- Verify source dimensions before choosing a hero. Do not generate larger variants than the original and call them sharper. Explain a source-resolution limit or choose another source.
- Use width/height or aspect-ratio to reserve space, object-fit and a deliberately inspected focal point. Supply srcset/sizes or a suitable picture set when the source warrants it.
- Do not lazy-load the primary above-fold image. Lazy lower-page images must be loaded before full-page capture. A blank unscrolled screenshot is not proof the page is broken.
- Failed images must not widen a grid through intrinsic alt-text width. Use min-width:0 for flexible children and a bounded, named fallback. Remove misleading source credits when a fallback replaces an image.

## Keyboard and assistive structure

- Logical heading structure and landmarks, a working skip link, visible focus and meaningful accessible names. No arrow-only link without a name.
- Native dialog when available: focus enters, remains inside while open, closes by explicit button and Escape, and returns to the trigger. Define a route for unsupported dialog browsers.
- No focusable content in closed menus or hidden panels. Avoid destroying a focused input on each keystroke.
- Respect reduced motion, including scripted scrolling. Reading content must not depend on animation firing.
- JavaScript-off mode should retain navigation/content and explain unavailable tools. Hide inert controls instead of showing fake success.

## Handoff

Shared chrome/content/fixtures have one editable source. A build command should be repeatable; include the source and output boundary. Do not call duplicated handwritten data a scalable architecture. Report which behaviors were actually exercised, not merely included in source.
