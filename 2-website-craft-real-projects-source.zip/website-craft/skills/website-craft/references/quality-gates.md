# Objective gates, and judgment that still needs a person

These are baseline review gates, not a performance guarantee or an accessibility certificate. Record the actual result and conditions. An unavailable check stays untested. A user-approved existing brand may need a different composition; it does not remove readability requirements.

| Area | Baseline pass criterion | Evidence |
|---|---|---|
| Text contrast | WCAG AA: normal text at least 4.5:1; large text at least 3:1. Large means at least 24 CSS px, or about 18.67 CSS px bold. | Computed foreground/background values and ratio, including worst-case photo/gradient backing. Do not eyeball a ratio. |
| UI contrast | Essential control outlines/icons and meaningful state graphics at least 3:1 against adjacent colours, unless a defined exception applies. | Computed ratio and inspected selected/focus/error states. |
| Targets | Aim for 44x44 CSS px for ordinary touch controls. WCAG 2.2 AA baseline is 24x24 or its defined spacing/exception conditions. | Actual element bounds on phone, including close/remove/filter controls, not only the main CTA. Avoid tiny utility actions. |
| Layout | No page-wide horizontal overflow at 320/390/768/1024/1440, no clipped core text, no overlapping controls. | Measured scrollWidth plus actual full-page pixels. Supplemental horizontal datasets need a visible scroll affordance and readable summary. |
| Keyboard | Every primary action usable in a logical Tab/Shift+Tab order. Focus is visible; dialog enters/traps/returns; Escape closes overlays. | Actual keyboard traversal, not just an event-handler search. |
| Forms/data | Invalid/empty/corrected/error/recovery and return states pass; prepared text exactly matches current fields; unsafe text remains text. | Click tests and exported/copied payload inspection. |
| Images | All expected assets decode, intentional crop at each composition, no required photo upscaled beyond useful source resolution. | Natural dimensions, rendered sizes and actual pixels at target density. |
| Performance | Set a project budget before build. For a small static specimen, start with <=1.5 MB initial uncached transfer on phone and <=150 KB compressed authored JS; change only for a documented content need. | Record transfer size, cache state, viewport, device/network/CPU conditions. Fonts/media count. These are project budgets, not web standards. |
| Core Web Vitals | When an actual suitable measurement exists: good LCP <=2.5s, INP <=200ms, CLS <=0.1, assessed at the 75th percentile for field claims. | State field vs lab. A local server run is not field evidence; a single local navigation cannot establish INP. |
| Motion/failure | Reduced-motion content visible and useful. Missing image/storage/clipboard/script has an honest recovery route. | Actually simulate the failure; do not claim a catch block proves recovery. |
| Product quality | The primary visitor can finish the task and correct a mistake, with specific content and a coherent visual world. | Whole-journey screenshots and reviewer judgment. Counts and automated scores cannot pass this row. |

Standards references to verify when applying: https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html ; https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html ; https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html ; https://web.dev/articles/vitals .
