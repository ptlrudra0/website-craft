# Candidate revision 2 / 5 November 2026

Changes after an independent new-domain implementation exercise: unattended optional-reference route; domain-specific jobs/evidence/asset roles/journeys/state maps for eight domains; implementation floor; optional original persistence/copy/export kernel and real browser tests; objective contrast/target/layout/performance review gates; paired variation exercise explicitly optional.

Scope limits: domain entries are authored decision guidance, not cleared photo packs or validated industry executions. Bundled four motifs are limited starting artwork, not useful imagery for every domain. The independent exercise and local authored specimens do not prove native installation or superior design across models. Physical devices, screen readers and Safari remain untested.

## Candidate v3 (unpublished)
- Optional original flat-editorial subject family: twelve SVGs in four subject groups, source metadata, gallery and download-payload browser tests. This is one visual language, not broad visual-style coverage or real photography.
