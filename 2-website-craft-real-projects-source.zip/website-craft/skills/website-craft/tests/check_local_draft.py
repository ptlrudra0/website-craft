from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,json
import os
root=Path(__file__).resolve().parents[1];out=root/'test-output';out.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8772','--directory',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);results={}
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox']);c=b.new_context(permissions=['clipboard-read','clipboard-write']);q=c.new_page();q.goto('http://localhost:8772/');q.evaluate('''async()=>{window.kernel=await import('/patterns/local-draft.js');window.store=kernel.createLocalDraft({key:'kernel-test-v1',validate:x=>x&&x.version===1&&typeof x.text==='string'&&x.text.length<=100});}''');assert q.evaluate('store.read().status')=='empty';assert q.evaluate("store.write({version:1,text:'test'}).status")=='saved';assert q.evaluate('store.read().value.text')=='test';assert q.evaluate("store.write({version:2,text:'bad'}).status")=='invalid';q.evaluate("localStorage.setItem('kernel-test-v1','{bad')");assert q.evaluate('store.read().status')=='invalid';q.evaluate("localStorage.setItem('kernel-test-v1',JSON.stringify({version:99,text:'bad'}))");assert q.evaluate('store.read().status')=='invalid';results['read_write_schema_corruption']=True
  assert q.evaluate("kernel.copyPrepared('').then(x=>x.status)")=='empty';assert q.evaluate("kernel.copyPrepared('exact test payload').then(x=>x.status)")=='copied';assert q.evaluate('navigator.clipboard.readText()')=='exact test payload';results['clipboard_actual']=True
  q.evaluate("()=>{window.receivedChange=null;window.off=store.watch(x=>window.receivedChange=x);}");other=c.new_page();other.goto('http://localhost:8772/');other.evaluate("localStorage.setItem('kernel-test-v1',JSON.stringify({version:1,text:'other tab'}))");q.wait_for_function('window.receivedChange?.status===\'changed\'');assert q.evaluate('receivedChange.value.text')=='other tab';q.evaluate('off()');results['cross_tab_changed_and_unsubscribe']=True
  assert q.evaluate("kernel.downloadPrepared('abc','../bad.txt').status")=='invalid-filename'
  with q.expect_download() as dl:q.evaluate("kernel.downloadPrepared('line one\\nline two','kernel-test.txt')")
  dl.value.save_as(str(out/'kernel-test.txt'));assert (out/'kernel-test.txt').read_text()=='line one\nline two';results['actual_download_payload']=True
  q.evaluate("Object.defineProperty(navigator,'clipboard',{value:{writeText:()=>Promise.reject(new Error('denied'))},configurable:true})");assert q.evaluate("kernel.copyPrepared('test').then(x=>x.status)")=='manual-copy-required';results['clipboard_denied']=True
  q.evaluate("Object.defineProperty(window,'localStorage',{get(){throw new Error('blocked')},configurable:true})");assert q.evaluate('store.read().status')=='unavailable';assert q.evaluate("store.write({version:1,text:'test'}).status")=='unavailable';results['storage_blocked']=True;b.close()
finally:s.terminate();s.wait()
(out/'checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
