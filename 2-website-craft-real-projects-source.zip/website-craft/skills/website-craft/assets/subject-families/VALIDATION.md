# Local asset-family review

Twelve authored SVG files parsed and rendered in Chromium, all12actual raster previews visually inspected as four family boards. Gallery at320/390/768/1440 had no page overflow or unloaded images. All12actual download links were clicked in fresh Chromium pages and the saved payloads matched the bundled SVG sources byte-for-byte. A reused-page download wait timed out; the isolated-page test passed. Each image has source/rights/role/crop/fallback/exclusion metadata in catalog.json.

These are flat conceptual subject illustrations, not photographic realism, factual product documentation or proof of craftsmanship, venue layout or safe process. They suit a deliberately illustrated website direction. They are not a substitute for approved real photography where physical appearance matters. The process drawing does not teach a safe/correct making technique. The spatial drawing is not a floorplan.

Tests: Python Playwright, Pillow, installed Chromium; set CHROME_PATH if needed. python tests/check_gallery.py writes test-output and uses temporary local port8774. Real-device, screen-reader, commercial-project fit and named coding-client compatibility are untested. No public release yet.
