# Original subject illustration families

Twelve original SVG compositions in four deliberately different but internally coherent families: clay studio, quiet stay, carry goods and print room. Each has a lead subject, detail and contextual composition. These are bundled editable assets under MIT, not reference links or copied photographs.

All scenes and objects are fictional. Do not claim they show an actual workshop, accommodation, inventory, maker, accessibility feature or tested product. No dimensions or instructional safety claims. Use genuine approved photography when the visitor needs factual product/venue evidence.

Each item has a role, source, rights, description, crop guidance, fallback and exclusions in catalog.json. SVG viewBox1200x900. Preserve subject proportions. Palette edits are permitted; avoid misleading alteration of an actual product when replacing illustrations later. These compositions are a small usable family library, not proof of broad industry coverage or original commissioned photography.
