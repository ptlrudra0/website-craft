from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,json,time
from PIL import Image,ImageDraw
import os
r=Path(__file__).resolve().parents[1];out=r/'test-output';out.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8774','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);result=[]
try:
 time.sleep(.5)
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for w in [320,390,768,1440]:
   q=b.new_page(viewport={'width':w,'height':1000});q.goto('http://localhost:8774/');q.wait_for_load_state('networkidle');q.screenshot(path=str(out/f'gallery-{w}.png'),full_page=True);result.append({'width':w,**q.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,unloaded:[...document.images].filter(i=>!i.naturalWidth).length})''')});assert not result[-1]['overflow'] and result[-1]['unloaded']==0;q.close()
  q=b.new_page(viewport={'width':1200,'height':900});items=json.loads((r/'catalog.json').read_text())
  q.goto('http://localhost:8774/')
  links=q.locator('a[download]');assert links.count()==len(items)
  for n in range(links.count()):
   href=links.nth(n).get_attribute('href')
   dpage=b.new_page(accept_downloads=True);dpage.goto('http://localhost:8774/')
   with dpage.expect_download() as download_info:dpage.locator('a[download]').nth(n).click()
   download=download_info.value
   assert Path(download.path()).read_bytes()==(r/href).read_bytes()
   dpage.close()
  result.append({'downloads':len(items),'payloads':'byte-identical SVG originals'})
  for item in items:q.goto('http://localhost:8774/'+item['file']);q.screenshot(path=str(out/(item['id']+'.png')))
  b.close()
finally:s.terminate();s.wait()
for fam in ['clay-studio','quiet-stay','carry-goods','print-room']:
 board=Image.new('RGB',(1500,440),'#f3f0e8')
 for n,item in enumerate([i for i in items if i['family']==fam]):
  im=Image.open(out/(item['id']+'.png'));im.thumbnail((480,360));board.paste(im,(n*500+10,30));ImageDraw.Draw(board).text((n*500+10,405),item['role'],fill='black')
 board.save(out/(fam+'-board.jpg'),quality=95)
(out/'checks.json').write_text(json.dumps(result,indent=2));print(result)
