/* Original MIT helper. No network, no remote storage, no UI framework.
   Call read() before write(). Supply a strict versioned schema validator.
   Example: const store=createLocalDraft({key:'project-v1',validate,isBlank});
   Keep UI state separate. Apply errors/status visibly; never announce sent.
*/
export function createLocalDraft({key,validate}) {
  if(typeof key!=='string'||!key||typeof validate!=='function')throw new TypeError('A storage key and validator are required.');
  function read(){
    let raw;
    try{raw=localStorage.getItem(key);}catch{return {status:'unavailable',value:null};}
    if(raw===null)return {status:'empty',value:null};
    try{const value=JSON.parse(raw);return validate(value)?{status:'loaded',value}:{status:'invalid',value:null};}
    catch{return {status:'invalid',value:null};}
  }
  function write(value){
    if(!validate(value))return {status:'invalid'};
    try{localStorage.setItem(key,JSON.stringify(value));return {status:'saved'};}
    catch{return {status:'unavailable'};}
  }
  function watch(onChange){
    const handler=event=>{
      if(event.key!==key)return;
      if(event.newValue===null){onChange({status:'cleared',value:null});return;}
      try{const value=JSON.parse(event.newValue);onChange(validate(value)?{status:'changed',value}:{status:'invalid',value:null});}
      catch{onChange({status:'invalid',value:null});}
    };
    window.addEventListener('storage',handler);
    return ()=>window.removeEventListener('storage',handler);
  }
  return {read,write,watch};
}
export async function copyPrepared(text){
  if(typeof text!=='string'||!text.trim())return {status:'empty'};
  try{await navigator.clipboard.writeText(text);return {status:'copied'};}
  catch{return {status:'manual-copy-required'};}
}
export function downloadPrepared(text,filename='local-draft.txt',mime='text/plain;charset=utf-8'){
  if(typeof text!=='string'||!text.trim())return {status:'empty'};
  if(!/^[a-zA-Z0-9._-]{1,80}$/.test(filename))return {status:'invalid-filename'};
  const url=URL.createObjectURL(new Blob([text],{type:mime}));
  const link=document.createElement('a');link.href=url;link.download=filename;
  document.body.append(link);link.click();link.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
  return {status:'download-started'}; // Verify the actual file before claiming a test pass.
}
