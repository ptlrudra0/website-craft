# Local draft kernel

Original optional ES module, not a complete form or a universal architecture. Supply a strict versioned schema validator and your own UI, focus, validation, review invalidation and undo. Call read before write so an invalid saved record is reported rather than silently overwritten. No external dependency or network operation.

Result states are data for your visible UI. Do not translate saved/copied/download-started into sent/booked/ordered. Show selectable prepared text when clipboard is absent/denied; provide an actual download when persistence fails. watch returns an unsubscribe function and reports other-tab events without applying them. The application decides whether to preserve, replace or merge.

Test with Python Playwright and installed Chromium: python tests/check_local_draft.py from the skill folder. Set CHROME_PATH if needed. A temporary local server uses port 8772 and test-output stores results. Six browser scenarios verified locally: read/write/schema/corrupt input; actual clipboard readback; actual other-tab event and unsubscribe; actual downloaded payload and invalid filename; clipboard denial; blocked storage. This is a kernel test, not screen-reader, Safari, native-agent or full-application proof.
