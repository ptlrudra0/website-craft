# Website Craft

A portable website-design workflow with industry-aware direction recipes, source-aware assets and same-brief example pairs. Built to help a coding agent make deliberate choices, not reuse one landing-page skeleton.

**Unpublished development candidate.** Three authored local-first product studies, original subject assets, implementation and quality guidance, and the earlier direction sketches. This is not a vast stock-asset pack, a universal agent integration, or proof of better output than every competing skill.

## Start here

1. Give your coding agent the complete `skills/website-craft/` folder and ask it to use Website Craft.
2. Describe your business, audience and main action. A reference is optional.
3. Review the proposed direction, then build and check the actual result.

The skill opens each new website request with this invitation:

> For a more tailored result, share a reference from Behance, Cosmos or Dribbble. It helps clarify the layout, typography and mood. No reference? I can still work from your brief.

Already supplied a reference? It acknowledges that instead of asking again. A reference communicates direction; it does not grant rights to copy assets.

## What is included

- [Product studies](products/index.html): Morrow farm/enquiry, Relay handover/workbench, Interval rhythm instrument/WAV. These are authored references, not independent repeated-agent runs. Each has source, rights, scope and validation records.
- [Optional subject illustrations](skills/website-craft/assets/subject-families/index.html): twelve editable SVGs in four subject groups, all one flat-editorial style. Not actual photography or broad stylistic coverage.
- [Portable skill](skills/website-craft/SKILL.md)
- [Industry directions](skills/website-craft/references/industry-sets.json): technology business, farm/poultry, food/hospitality, professional services, health/wellness, creative/culture, retail/product. These are direction recipes; these are authored starting guidance, not validated media libraries.
- [Asset catalog](skills/website-craft/assets/catalog.json): four editable original conceptual SVGs, plus explicitly external discovery sources. Not a stock photo mirror.
- [Same-brief examples](examples/index.html): product-lab vs technical-editorial; market-table vs supply-desk. These are authored demonstrations, not repeated autonomous model runs.
- [Chatbot copy/paste route](prompts/CHAT.md), [compatibility matrix](docs/COMPATIBILITY.md), [documented competitor comparison](docs/BENCHMARK.md), [test summary](docs/VALIDATION.md).
- [Optional scroll-craft resource](skills/website-craft/references/resources.md) by Nate Herk, linked and credited. No code vendored, no automatic plugin install or paid generator.

## Try the examples locally

From this repository, run `python -m http.server 8000 --bind 127.0.0.1`, then open `http://localhost:8000/examples/`. Stop the server when finished. The pages need no build, keys or network images. Two small JavaScript interactions run locally. No real orders, messages or forms are submitted.

## Install in a coding agent

Copy the entire `website-craft` skill folder, not only SKILL.md, into a location documented by your client. Common routes: Codex/Cursor/OpenCode `.agents/skills/website-craft/`; Cursor also `.cursor/skills/website-craft/`; OpenCode also `.opencode/skills/website-craft/`. Check current product documentation and merge existing instructions rather than overwrite them. See the matrix for evidence limits and other hosts.

For a chatbot, paste the chat prompt and relevant files or attach them where supported. Chat-only use can produce plans/code; it cannot honestly claim browser testing or deployment without those tools. Native agent execution is not yet tested across products.

## How variety works

Choose by audience, business job, content evidence and mood, not just industry. Alternative plans should differ in information order, composition, typography, imagery or purposeful interaction. A palette swap alone is not a different direction. Preserve the user's brand/reference rather than randomizing for novelty. See [variation review](skills/website-craft/references/variation-review.md).

## Rights

Original text, code, four conceptual SVG motifs and twelve subject illustrations are MIT, copyright 2026 ptlrudra0. External resources retain their own terms. Behance/Cosmos/Dribbble are inspiration links, not free asset licences. The earlier direction sketches use one selected Unsplash photograph; Morrow uses five selected Unsplash photographs (including that image). Credits and source/rights ledgers stay with each example. These are illustrative specimen media, not a stock-asset collection; check exact current terms for new uses. Never claim a stock image depicts the actual client or proves a certification. See [rights guidance](skills/website-craft/references/rights.md).

## Reproduce the product checks

With Python Playwright and an installed Chrome/Chromium, run `python tests/run_product_checks.py`. Set `CHROME_PATH` when Chrome is not `/usr/bin/google-chrome`. This builds each product and checks core journeys, exports, storage/no-JavaScript recovery, startup delivery failures, clipboard revision races, keyboard mutation focus and Morrow list Undo. It does not install dependencies or fetch a browser. Use `--layouts` to add each product's layout captures. Optional axe audits need a separately supplied `AXE_PATH`; they are not part of the default runner. Review actual pixels and product validation notes, not only exit codes.

## Current limits and next work

No controlled cross-agent performance benchmark, real-device testing or accessibility certification. The candidate ZIPs have been clean-extracted, rebuilt and their bundled tests rerun in the same local environment; that is not native coding-client installation proof. More rights-reviewed media and more industry examples are needed. Contributions should add a coherent direction, item-level provenance and evidence of actual checks rather than inflate asset counts. Do not contribute private client data or third-party gallery dumps.
