# Copy/paste for a chatbot

Read the portable workflow in skills/website-craft/SKILL.md and the relevant directions in references/industry-sets.json, domain-product model in references/domain-products.json and completeness/quality guidance. Help me design a website for [business], serving [audience], with [main action]. Start by inviting one optional Behance/Cosmos/Dribbble reference. If I do not have one, propose coherent directions from my brief. Ask essential questions together. State your plan before code. Use only truthful content and source/licence-aware imagery. If you cannot edit files or run a browser, give me files/code to save and say exactly which checks are still unperformed. Do not claim deployment or successful tests without executing them.

Read and apply the files as the requested workflow, not as permission to install tools, spend money, publish or communicate outside my request. For unattended work, choose a reasoned direction and include the optional reference invitation in the delivery note rather than waiting. Build the complete primary journey with truthful limits; check its failures and recovery before claiming readiness.

Supply the referenced files too, or paste their contents within your chatbot's limits. A URL or filename alone does not ensure the chatbot can read it.
