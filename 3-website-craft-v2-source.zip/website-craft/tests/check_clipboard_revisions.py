from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,os,json
root=Path(__file__).resolve().parents[1];out=root/'test-output/clipboard';out.mkdir(parents=True,exist_ok=True)
server=subprocess.Popen(['python','-m','http.server','8785','--directory',str(root/'products')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.3);checks=[]
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for product in ['relay','morrow','supply']:
   for rejected in [False,True]:
    q=browser.new_page(viewport={'width':390,'height':1000});q.add_init_script("window.copyJobs=[];Object.defineProperty(navigator,'clipboard',{value:{writeText:text=>new Promise((resolve,reject)=>copyJobs.push({text,resolve,reject}))}})")
    if product=='relay':
     q.goto('http://localhost:8785/relay/workbench.html');q.locator('[data-load-example]').click();review='#review';copy='#copy';edit='#draft-title';status='#copy-status';result='#review-result'
    elif product=='morrow':
     q.goto('http://localhost:8785/morrow/product-table-eggs.html');q.locator('.add-form button').click();q.goto('http://localhost:8785/morrow/enquiry.html');review='#enquiry-form button[type=submit]';copy='[data-copy]';edit='textarea[name=notes]';status='#copy-status';result='#enquiry-result'
    else:
     q.goto('http://localhost:8785/morrow/supply.html');q.locator('input[name=volume]').fill('20 dozen');review='#supply-form button';copy='[data-copy-supply]';edit='input[name=volume]';status='#supply-status';result='#supply-result'
    q.locator(review).first.click();q.locator(copy).click();q.locator(edit).fill('Revised content');assert q.locator(result).is_hidden();q.locator(review).first.click();q.locator(copy).click()
    q.evaluate('copyJobs[0].'+('reject(new Error("blocked"))' if rejected else 'resolve()'));q.wait_for_timeout(30);assert q.locator(status).inner_text()==''
    q.evaluate('copyJobs[1].resolve()');q.wait_for_timeout(30);assert 'Copied.' in q.locator(status).inner_text();assert 'Revised content' in q.evaluate('copyJobs[1].text');assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');q.wait_for_timeout(400);q.locator(status).scroll_into_view_if_needed();q.screenshot(path=str(out/f'{product}-current-copy.png'));checks.append({'product':product,'oldCopyRejected':rejected,'staleStatusIgnored':True,'currentCopyConfirmed':True});q.close()
  browser.close()
finally:server.terminate();server.wait()
(out/'checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
