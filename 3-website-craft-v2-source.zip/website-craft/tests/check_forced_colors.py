from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,os,json
r=Path(__file__).resolve().parents[1];out=r/'test-output/forced-colors';out.mkdir(parents=True,exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8797','--directory',str(r/'products')],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.3);checks=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for width in [320,390,1024]:
   q=b.new_page(viewport={'width':width,'height':844},forced_colors='active');q.goto('http://localhost:8797/interval/instrument.html');assert q.locator('.step[aria-pressed=true]').first.evaluate('(x)=>parseFloat(getComputedStyle(x).borderTopWidth)===3');assert q.locator('.step[aria-pressed=false]').first.evaluate('(x)=>parseFloat(getComputedStyle(x).borderTopWidth)===1');assert q.locator('.step[aria-pressed=true]').first.evaluate('(x)=>getComputedStyle(x,"::after").backgroundColor!=="rgba(0, 0, 0, 0)"');q.locator('#pattern-name').evaluate('(x)=>window.scrollTo(0,x.getBoundingClientRect().top+scrollY-30)');q.screenshot(path=str(out/f'interval-{width}.png'));q.goto('http://localhost:8797/relay/workbench.html');q.locator('[data-load-example]').click();q.locator('[data-filter=blocked]').click();assert q.locator('[data-filter=blocked]').evaluate('(x)=>getComputedStyle(x).textDecorationLine.includes("underline")');q.locator('.filters').scroll_into_view_if_needed();q.wait_for_timeout(3800);q.screenshot(path=str(out/f'relay-{width}.png'));q.goto('http://localhost:8797/morrow/range.html');q.locator('[data-filter=eggs]').click();assert q.locator('.filter.active').evaluate('(x)=>getComputedStyle(x).textDecorationLine.includes("underline")');q.goto('http://localhost:8797/morrow/product-table-eggs.html');assert q.locator('.pack-options input:checked+span').evaluate('(x)=>parseFloat(getComputedStyle(x).borderTopWidth)===3');assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');checks.append({'width':width,'stepOnOffDistinct':True,'filterSelectionMarked':True,'packSelectionMarked':True});q.close()
  b.close()
finally:s.terminate();s.wait()
(out/'checks.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
