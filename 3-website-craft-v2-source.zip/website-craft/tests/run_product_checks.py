"""Sequential local regression entrypoint. No dependency installation or network fetch."""
from pathlib import Path
import argparse, subprocess, sys
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--layouts',action='store_true',help='Also capture each product layout suite')
args=parser.parse_args()
def run(path):
 print('Running '+str(path.relative_to(root)),flush=True)
 subprocess.run([sys.executable,str(path)],check=True,cwd=path.parent.parent)
for name in ['morrow','relay','interval']:
 run(root/'products'/name/'build.py')
for name,test in [('morrow','check_journeys.py'),('morrow','check_failures.py'),('morrow','check_list_undo.py'),('relay','check_journeys.py'),('interval','check_product.py')]:
 run(root/'products'/name/'tests'/test)
for test in ['check_startup_recovery.py','check_clipboard_revisions.py','check_focus_mutations.py','check_forced_colors.py']:
 run(root/'tests'/test)
if args.layouts:
 for name in ['morrow','relay']:
  run(root/'products'/name/'tests/check_layouts.py')
 print('Interval check_product.py already captures its layout matrix.',flush=True)
print('Core checks passed in this environment. Inspect pixels and read validation limits.',flush=True)
