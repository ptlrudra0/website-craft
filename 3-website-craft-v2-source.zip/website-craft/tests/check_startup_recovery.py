from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,shutil,os
r=Path(__file__).resolve().parents[1];o=r/'test-output/startup-recovery';o.mkdir(parents=True,exist_ok=True)
s=subprocess.Popen(['python','-m','http.server','8782','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.3);results=[]
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for name,route in [('morrow','enquiry.html'),('relay','workbench.html'),('interval','instrument.html')]:
   for dependency in ['app.js',{'morrow':'products.js','relay':'fixture.js','interval':'fixture.js'}[name]]+(['synth.js'] if name=='interval' else []):
    q=browser.new_page(viewport={'width':390,'height':844});q.route('**/'+dependency,lambda t:t.abort());q.goto(f'http://localhost:8782/products/{name}/{route}');q.wait_for_load_state('networkidle');print(name,dependency,q.locator('#startup-text').inner_text(),flush=True);assert q.locator('#startup-note').is_visible();assert q.locator('#startup-retry').is_visible();assert 'prepar' in q.locator('#startup-text').inner_text().lower();assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');
    if name=='morrow':assert q.locator('#enquiry-form button[type=submit]').is_disabled();assert q.locator('#enquiry-form input').first.is_disabled()
    else:assert q.locator('#'+('tool' if name=='relay' else 'instrument')).is_hidden()
    q.screenshot(path=str(o/f'{name}-{dependency}-failure.png'),full_page=True);q.unroute('**/'+dependency);q.locator('#startup-retry').click();q.wait_for_load_state('networkidle');assert q.locator('#startup-note.ready').count()==1;results.append({'product':name,'blocked':dependency,'notice':'visible','retry':'recovered'});q.close()
  browser.close()
finally:s.terminate();s.wait()
(o/'checks.json').write_text(json.dumps(results,indent=2));print(results)
