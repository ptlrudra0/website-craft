from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,statistics,os
r=Path(__file__).resolve().parents[1];o=r/'test-output';o.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8778','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.3);results=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for product,route in [('morrow','index.html'),('morrow','enquiry.html'),('relay','index.html'),('relay','workbench.html'),('interval','index.html'),('interval','instrument.html')]:
   samples=[]
   for i in range(3):
    ctx=b.new_context(viewport={'width':390,'height':844});q=ctx.new_page();q.add_init_script("window.layoutShift=0;new PerformanceObserver(l=>{for(const e of l.getEntries())if(!e.hadRecentInput)window.layoutShift+=e.value}).observe({type:'layout-shift',buffered:true});window.lcp=0;new PerformanceObserver(l=>{for(const e of l.getEntries())window.lcp=e.startTime}).observe({type:'largest-contentful-paint',buffered:true});")
    q.goto('http://localhost:8778/products/'+product+'/'+route);q.wait_for_load_state('networkidle');q.evaluate('document.fonts.ready');q.wait_for_timeout(100);samples.append(q.evaluate("()=>({lcpMs:window.lcp,cls:window.layoutShift,transferBytes:performance.getEntriesByType('resource').reduce((s,r)=>s+r.transferSize,0)+performance.getEntriesByType('navigation')[0].transferSize,domContentLoadedMs:performance.getEntriesByType('navigation')[0].domContentLoadedEventEnd})"));ctx.close()
   results.append({'product':product,'route':route,'samples':samples,'medianLcpMs':statistics.median(x['lcpMs'] for x in samples),'maximumCls':max(x['cls'] for x in samples),'maximumTransferBytes':max(x['transferBytes'] for x in samples)});print(results[-1],flush=True)
  b.close()
finally:s.terminate();s.wait()
(o/'local-load-measurements.json').write_text(json.dumps({'conditions':'Headless Chromium on local Python HTTP server,390x844, fresh browser context each run,3runs per route, no network/CPU throttling, initial viewport only, same environment. Lab observations, not field Core Web Vitals or real mobile speed. Offscreen lazy images not forced. No interactions: INP not measured.','results':results},indent=2))
