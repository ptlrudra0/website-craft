# Validation guide, 6 November 2026

## Current product candidate

Morrow, Relay and Interval are local authored studies, not deployed businesses or independent model trials. Each keeps its own scope and evidence:

- `products/morrow/VALIDATION.md`: farm range, enquiry list and supply brief; 10 pages.
- `products/relay/VALIDATION.md`: handover editing, review and Markdown export; 5 pages.
- `products/interval/VALIDATION.md`: instrument, synthesis and WAV export; 5 pages.
- `CANDIDATE-STATUS.md`: cross-product findings and revisions.
- `LOCAL-LOAD-MEASUREMENTS.json`: three fresh-context local samples per listed route. Not field performance, INP or a mobile speed claim.

The current archive was freshly extracted, all three products rebuilt with byte-identical HTML/data outputs, then core journeys and integration checks rerun in the same installed Python/Chromium environment. This is packaging/build evidence, not native coding-client or cross-browser proof.

The default `python tests/run_product_checks.py` reproduces core checks and current builds. `--layouts` adds the product layout suites. Optional axe tests require `AXE_PATH`. Tests write ignored `test-output/` folders and use temporary localhost ports; run one suite at a time. Pixel inspection remains necessary: passing overflow checks did not catch an earlier transient toast covering an empty-state action. That state was corrected and reinspected.

Current evidence includes actual clipboard readback/downloaded text, WAV PCM structure/signal assertions, seven blocked JavaScript dependency/retry cases, six delayed clipboard resolve/reject cases, mutation-focus keyboard journeys, and list clear/removal Undo. Audio structure does not establish listening quality. All three products retain explicit no-send, local/session-storage and failure limitations.

Not established: physical devices, Safari, screen-reader navigation, listening quality, native coding-client installation/execution, field performance, accessibility certification, production forms/payments or controlled model superiority.

## Earlier direction sketches

Four authored example pages plus the comparison index rendered locally in Chromium at390,768,1440 CSS pixels. Final check covers document overflow, local link targets, page errors, one H1, image loading, first-tab visible focus and reduced-motion auto scrolling. Actual phone/desktop screenshots inspected after fixes. Mobile footer separation, enlarged mobile type-panel clipping and an earlier missing README target were fixed.

Interactive checks: technology request-flow demo advances and resets with truthful no-send text; poultry kitchen-type selector changes guidance and pressed state; FAQ disclosure opens. No real order, message, inventory, customer claim or certification exists.

The final poultry pair uses one source-inspected Erol Ahmed photograph under Unsplash terms (credit/source in examples/media/CREDITS.md), not an asset corpus. The technology diagrams are conceptual, not a fake real product screenshot. The pairs are authored examples, NOT repeated independent agent runs or evidence of universal variety.

Not tested: native agent installation/execution, real devices, screen-reader navigation, every contrast pair, production forms/checkout, deployment conversions or universal accessibility. No superiority or accessibility-certification claim. Primary text colours are chosen for strong contrast; this is not a full automated contrast audit.

Reproduce narrow checks: install Python playwright, set CHROME_PATH to an installed Chrome/Chromium if not /usr/bin/google-chrome, run python tests/check_examples.py. Ignored test-output/ contains results/screenshots. Inspect pixels too.
