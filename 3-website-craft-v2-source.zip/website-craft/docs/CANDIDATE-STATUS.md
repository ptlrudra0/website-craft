# Development candidate / 6 November 2026

Not a published release. Existing early examples preserved.

Three complete authored studies are included in products/. Morrow10pages, Relay5pages, Interval5pages. All source builds and bundled browser checks were executed again from extracted candidate archives, not only development folders.50/25/25layout frames plus each product's journey/failure tests. Local Chromium, one environment. Detailed records stay with each study. No actual physical devices, Safari, screen readers, field performance or native coding-client installation proof. No listening-quality claim.

The skill adds unattended reference handling,8domain product models, implementation floor, objective quality gates, optional tested local draft kernel and12original subject SVGs in one optional illustrative style. Category counts are not quality evidence. Earlier four direction sketches remain historical; they were rejected as insufficiently finished, and are not relabelled as the stronger studies.

An independent new-domain exercise informed revisions but its private evaluation archive and third-party images are not redistributed here. No claim of cross-model superiority. Check current client documentation and execute a native installation experiment separately before claiming support.

No payment, outside messaging, commercial hosting account or account setup. Local session/storage behavior is explicit. Every specimen retains its own rights ledger and notices. Review whole package and deployment destination before public release.

Initial-load lab review found and fixed substantial deferred-tool reveal layout shift in Relay/Interval and empty-list insertion in Morrow. See LOCAL-LOAD-MEASUREMENTS.json for final3-run lab conditions and values. No field performance claim. All touched product journey/layout tests rerun and actual phone tool pixels reinspected.

Partial JavaScript delivery was tested separately from disabled JavaScript. Seven blocked-script/fixture/synthesis routes now give visible reload recovery; Morrow controls remain disabled until setup. Failed tool shells collapse. Actual retry click recovery and phone failure pixels verified. See tests/check_startup_recovery.py.

Delayed clipboard completion review found a stale status race in Relay and both Morrow prepared drafts. Revision/request guards now ignore obsolete success/error callbacks. Six delayed-completion scenarios and actual clipboard journey checks passed. The test does not claim to cancel writes already dispatched to the browser.

Focused mutation checks found and fixed document-body focus loss after Morrow quantity changes/removal and Relay filtered state edits. Keyboard continuation and dialog return verified at 320/390/1024px; see tests/check_focus_mutations.py.

Morrow list removal/clear now has visible one-level page-session Undo. Recovery invalidates old enquiries, restores quantity and keyboard focus, and persists the restored list. Actual main/dialog recovery tested at 320/390/1024px. Later quantity/add/external updates or reload discard Undo; see product README. Fifty ordinary layouts and clipboard/focus regressions rerun.

Visual review caught a redundant Morrow toast covering the empty-state range link. Clear/removal/restore now use nonvisual live status with the persistent Undo notice, not an overlapping toast. Actual phone clear state reinspected; no toast overlay.

Forced-colors emulation found selected fills/dots erased in the instrument and filters. Added explicit system-color borders/underlines and a preserved step dot, revised the instrument legend, and verified actual phone pixels. Three widths and the full sequential core suite pass. Native OS high-contrast remains untested.
