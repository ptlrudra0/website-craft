# Relay / a local handover workbench

Candidate direction, not yet implemented or published. Original fictional technology product. No real company, incident telemetry, uptime, integration, customers, security certification, delivery endpoint or pricing. A local browser tool can be useful without pretending to be a connected SaaS platform. Do not ask for confidential incident details in this public specimen.

## Audience and task
A team lead needs to turn scattered, non-sensitive status notes into a clear next-shift handover. Understand the product, inspect a worked example, create a local handover with owner aliases and explicit next actions, review unresolved items, export readable Markdown. All example facts are fictional. No message is sent, system monitored, incident resolved or colleague notified.

## Visual contract
A practical technical field manual, distinct from the farm specimen. Deep navy canvas, pale blue working surfaces, electric orange for attention, ivory type. Sharp square corners and oversized numeric editorial section markers, compact mono metadata paired with direct geometric sans. Not another centered SaaS hero or neon gradient dashboard. Core visual: a legible original relay-path diagram that shows each editable handover item and its actual local state. No decorative fabricated telemetry, meaningless traces or random data.

Marketing composition: bold offset masthead, vertical product index, broad illustrated evidence panel from the real local tool, concise task walkthrough, permission/reality explanation, deep footer with docs and example. Product composition: paper-like task pane with labelled fields and real summary preview. Wide view uses three unequal zones: scope/status, editable handover, preview; phone becomes an ordered sequence with labelled navigation. Do not shrink the full dashboard into a tiny screenshot. Native controls over custom widgets where possible.

## Complete product surfaces
1. Overview: specific need -> actual usable workbench preview -> worked handover -> how to finish -> tool/docs links.
2. Workbench: title/shift alias, items with summary, state (needs attention/ready/blocked), owner alias and next action. Add/edit/remove, filters/counts, draft/review tabs, reset/undo, local save/load, export Markdown, no false notification.
3. Worked example: accessible real semantic content, same data shape as editor; load explicit fictional fixture only after confirming replacement if a nonempty draft exists.
4. Guide: what belongs in a handover, operational boundaries, short illustrative examples, exact data/persistence/export description. No unsupported safety/incident-response advice.
5. About specimen/credits: fictional boundary and original assets/fonts/licenses; no marketing success claims.

## Required state map
Empty editor; one item; multiple items; invalid title/missing action; remove then undo; clear with reversible restore; blocked item; filter no-match; successful save; persistence blocked; corrupted/unknown stored schema; export actual downloaded text; unsafe pasted markup rendered as text; edited content invalidates prepared preview; cross-tab update warning without overwriting unsaved edits. All user-entered state is local, no analytics/endpoints. No account/email/password or actual contact fields.

## Architecture
Single structured fixture/schema source. Shared layout/nav/footer/icon partials. Standard-library deterministic build or existing lightweight stack, not dependency sprawl. Dynamic editor uses DOM text nodes, controlled field construction and explicit validated data. Avoid arbitrary innerHTML. Preserve unsaved changes before destructive fixture/reset operations. Local storage failure must offer an actual download on the same page before navigation. Persistent content is convenience, not a promise of backup.

## Original asset family, with meaningful roles
- Relay mark: identifiable small symbol, not security/certification.
- Handover-path diagram: visualises actual local task state and has semantic text equivalent.
- Worked-example product frame generated from real tool state, not an imagined dashboard.
- Empty-state illustration: a blank relay card with explicit add-task prompt.
- Export/document icon set: consistent square-ended stroke, SVG viewBox, currentColor, labelled buttons.
No paid image generation or stock photograph needed: the actual product surface is the subject. No fake people/premises. Fonts from already verified OFL family or official source with retained notice; do not fetch remote fonts at runtime.

## Review boundary
All routes at 320/390/768/1024/1440, actual pixel review, task click/keyboard/recovery checks, normal plus no-JS/no-storage/image-failure modes, axe with manual incomplete-node review, actual exported file readback, no network data transfer. Physical devices/Safari/screen readers/native-agent installation remain untested unless genuinely checked. A complete visual specimen is not a live incident-management service. Compare whole product against whole reference, not only hero. Do not publish until reviewed separately from existing live preview.
