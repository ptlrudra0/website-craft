# Relay / local handover workbench

Original fictional technology-product specimen. Five complete surfaces: overview, editable workbench, worked example, field guide and reality/credits. Not a live company or team service. No account, notifications, analytics, payments, telemetry, integration or external submission. Use fictional or non-sensitive content only.

Serve locally: python -m http.server 8000 --bind 127.0.0.1. Edit src/pages and src/partials then run python build.py. fixture.json is the common example-data source for marketing illustration and editor. app.js and style.css are handwritten. No remote dependencies, build packages or keys.

Workbench: create/edit/remove/filter, undo, replace with confirmation, local save, safe text review, actual Markdown download/copy and storage-failure download recovery. Prepared review invalidates after edits. Another-tab changes warn instead of silently replacing current work. Browser local storage is a convenience copy, not backup or a security guarantee.

Tests use Python Playwright and installed Chrome/Chromium. Set CHROME_PATH if needed, then python tests/check_layouts.py and python tests/check_journeys.py. They use temporary port 8770 and write test-output/. Checks are not a physical-device, screen-reader or native coding-client compatibility claim.

Original text/code/illustrations MIT. Unmodified Manrope font files retain SIL OFL 1.1; included fonts/manrope-OFL.txt. No bundled stock photos.

Optional deep-state audit: set AXE_PATH to a locally installed axe.min.js and run python tests/check_deep_states.py. This third-party dependency is not bundled.
