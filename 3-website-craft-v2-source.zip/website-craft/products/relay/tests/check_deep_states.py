from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,json
import os
r=Path(__file__).resolve().parents[1];out=r/'test-output';out.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8770','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);results={}
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox']);c=b.new_context(viewport={'width':390,'height':1000},reduced_motion='reduce');q=c.new_page();q.goto('http://localhost:8770/workbench.html');q.locator('[data-load-example]').click();q.locator('#review').click();q.add_script_tag(path=os.environ['AXE_PATH']);a=q.evaluate("async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});return {violations:r.violations,incomplete:r.incomplete}}");results['populated_axe']={'violations':len(a['violations']),'incomplete':len(a['incomplete'])};(out/'populated-axe.json').write_text(json.dumps(a,indent=2));q.locator('#clear').click();q.add_script_tag(path=os.environ['AXE_PATH']);a=q.evaluate("async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});return {violations:r.violations,incomplete:r.incomplete}}");results['dialog_axe']={'violations':len(a['violations']),'incomplete':len(a['incomplete'])};q.keyboard.press('Tab');assert q.evaluate('document.activeElement.closest("dialog")!==null');q.keyboard.press('Shift+Tab');q.keyboard.press('Shift+Tab');assert q.evaluate('document.activeElement.closest("dialog")!==null');q.keyboard.press('Escape');assert q.locator('#clear').evaluate('(x)=>x===document.activeElement');results['dialog_keyboard_trap_escape_return']=True
  q.locator('#draft-title').fill('X'*100);q.locator('#draft-shift').fill('Y'*100)
  for x in q.locator('[data-key=title]').all():x.fill('W'*120)
  for x in q.locator('[data-key=owner]').all():x.fill('Z'*80)
  for x in q.locator('[data-key=action]').all():x.fill('M'*600)
  for w in [320,390,768,1024,1440]:
   q.set_viewport_size({'width':w,'height':1000});q.locator('#review').click();assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');q.screenshot(path=str(out/f'long-text-{w}.png'),full_page=True)
  results['maximum_lengths_no_overflow']=True;results['reduced_motion']=q.evaluate("getComputedStyle(document.documentElement).scrollBehavior==='auto'")
  q.set_viewport_size({'width':390,'height':1000});results['small_controls']=q.evaluate("[...document.querySelectorAll('#tool button')].filter(x=>x.getBoundingClientRect().width&&x.getBoundingClientRect().height).map(x=>({text:x.textContent,w:x.getBoundingClientRect().width,h:x.getBoundingClientRect().height})).filter(x=>x.h<44||x.w<44)");c.close()
  c=b.new_context(viewport={'width':390,'height':1000});c.add_init_script("localStorage.setItem('website-craft-relay-v1',JSON.stringify({version:1,title:'bad',shift:'',items:[{id:'x',title:'bad',owner:'',state:'evil',action:'bad'}]}))");q=c.new_page();q.goto('http://localhost:8770/workbench.html');assert q.locator('.task').count()==0;assert 'unavailable or unreadable' in q.locator('#storage-status').inner_text();results['corrupt_schema_rejected']=True;c.close()
  c=b.new_context(viewport={'width':390,'height':1000});q=c.new_page();q.route('**/media/*.svg',lambda route:route.abort());q.goto('http://localhost:8770/index.html');assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');results['failed_original_svg_no_overflow']=True;c.close();b.close()
finally:s.terminate();s.wait()
(out/'deep-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
