from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,json
import os
r=Path(__file__).resolve().parents[1];out=r/'test-output';out.mkdir(exist_ok=True);out.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8770','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);results=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for f in r.glob('*.html'):
   for w in [320,390,768,1024,1440]:
    q=b.new_page(viewport={'width':w,'height':1000},reduced_motion='reduce');errors=[];q.on('pageerror',lambda e:errors.append(str(e)));q.goto('http://localhost:8770/'+f.name);q.wait_for_load_state('networkidle');q.screenshot(path=str(out/f'{f.stem}-{w}.png'),full_page=True);data=q.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,broken:[...document.images].filter(i=>!i.naturalWidth).length})''');results.append({'page':f.name,'width':w,**data,'errors':errors});q.close()
  q=b.new_page(viewport={'width':1440,'height':1000});q.goto('http://localhost:8770/workbench.html');q.locator('[data-load-example]').click();assert q.locator('.task').count()==3;q.locator('#review').click();assert q.locator('#review-result').is_visible()
  with q.expect_download() as d:q.locator('#download').click()
  d.value.save_as(str(out/'actual-handover.md'));assert 'Navigation review' in (out/'actual-handover.md').read_text();q.screenshot(path=str(out/'populated-desktop.png'),full_page=True);q.set_viewport_size({'width':390,'height':1000});q.screenshot(path=str(out/'populated-phone.png'),full_page=True);q.locator('[data-key=title]').first.fill('changed');assert q.locator('#review-result').is_hidden();q.locator('.task-top button').first.click();assert q.locator('.task').count()==2;q.locator('#undo').click();assert q.locator('.task').count()==3;q.locator('[data-filter=blocked]').click();assert q.locator('.task').count()==1;q.reload();assert q.locator('.task').count()==3;b.close()
finally:s.terminate();s.wait()
(out/'checks.json').write_text(json.dumps(results,indent=2));print('layouts',len(results),'bad',[x for x in results if x['overflow'] or x['broken'] or x['errors']]);print('initial actual export/edit/undo/filter/persistence checks passed')
