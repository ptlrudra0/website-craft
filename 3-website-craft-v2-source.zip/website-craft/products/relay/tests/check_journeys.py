from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,json
import os
r=Path(__file__).resolve().parents[1];out=r/'test-output';out.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8770','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);results={}
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox']);c=b.new_context(viewport={'width':390,'height':1000},permissions=['clipboard-read','clipboard-write']);q=c.new_page();q.goto('http://localhost:8770/workbench.html');q.locator('#review').click();assert not q.locator('#draft-title').evaluate('(x)=>x.checkValidity()');q.locator('#draft-title').fill('Test');q.locator('#add').click();q.locator('#review').click();assert q.locator('#review-result').is_hidden();results['invalid_and_empty']=True
  q.locator('[data-key=title]').fill('<img src=x onerror=alert(1)>');q.locator('[data-key=action]').fill('Do the next thing');q.locator('#review').click();assert '<img' in q.locator('#review-text').inner_text();assert q.locator('#review-text img').count()==0;results['text_not_markup']=True;q.locator('#copy').click();q.wait_for_function("document.querySelector('#copy-status').textContent.includes('Copied')");assert '<img' in q.evaluate('navigator.clipboard.readText()');results['actual_clipboard']=True
  q.locator('[data-load-example]').click();assert q.locator('dialog').is_visible();q.locator('#cancel-replace').click();assert q.locator('[data-key=title]').input_value().startswith('<img');q.locator('[data-load-example]').click();q.keyboard.press('Escape');assert q.locator('dialog').is_hidden();q.locator('[data-load-example]').click();q.locator('#confirm-replace').click();assert q.locator('.task').count()==3;q.locator('#undo').click();assert q.locator('.task').count()==1;results['replace_cancel_escape_undo']=True
  second=c.new_page();second.goto('http://localhost:8770/workbench.html');second.locator('#draft-title').fill('Other tab');q.wait_for_function("!document.querySelector('#remote-warning').hidden");assert q.locator('#draft-title').input_value()=='Test';q.locator('#keep-local').click();assert q.locator('#remote-warning').is_hidden();results['cross_tab_no_silent_overwrite']=True
  q.locator('#review').click();q.locator('[data-key=action]').fill('new action');assert q.locator('#review-result').is_hidden();results['edit_invalidates']=True;c.close()
  c=b.new_context(viewport={'width':390,'height':1000});c.add_init_script("Object.defineProperty(window,'localStorage',{get(){throw new Error('no storage')}})");q=c.new_page();q.goto('http://localhost:8770/workbench.html');q.locator('[data-load-example]').click();assert q.locator('#emergency').is_visible()
  with q.expect_download() as dl:q.locator('#download-raw').click()
  dl.value.save_as(str(out/'actual-incomplete.md'));assert 'Incomplete local draft' in (out/'actual-incomplete.md').read_text();results['storage_recovery_actual_download']=True;c.close()
  c=b.new_context(viewport={'width':390,'height':1000},java_script_enabled=False);q=c.new_page();q.goto('http://localhost:8770/workbench.html');assert q.locator('noscript').is_visible();assert q.locator('#tool').is_hidden();assert q.locator('nav').is_visible();results['no_js_reading_navigation']=True;b.close()
finally:s.terminate();s.wait()
(out/'edge-checks.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
