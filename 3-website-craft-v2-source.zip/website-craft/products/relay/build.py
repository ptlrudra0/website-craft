from pathlib import Path
import json,html
r=Path(__file__).resolve().parent
parts={p.stem:p.read_text() for p in (r/'src/partials').glob('*.html')}
fixture=json.loads((r/'fixture.json').read_text())
esc=lambda s:html.escape(s,quote=True)
parts['example_items']=''.join('<article class="example-item"><span class="state '+esc(i['state'])+'">'+{'attention':'Needs attention','blocked':'Blocked','ready':'Ready'}[i['state']]+'</span><h3>'+esc(i['title'])+'</h3><p>'+esc(i['action'])+'</p><span class="mono">OWNER / '+esc(i['owner'])+'</span></article>' for i in fixture['items'])
for p in (r/'src/pages').glob('*.html'):
 s=p.read_text()
 for k,v in parts.items():s=s.replace('{{'+k+'}}',v)
 (r/p.name).write_text(s)
(r/'fixture.js').write_text('window.RELAY_EXAMPLE='+json.dumps(json.loads((r/'fixture.json').read_text()))+';\n')
print('Built',len(list((r/'src/pages').glob('*.html'))),'pages')
