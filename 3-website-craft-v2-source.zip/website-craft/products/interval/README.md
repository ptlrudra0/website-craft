# Interval

Original local browser rhythm instrument and five-page product study. Cobalt / warm yellow / cream. No account, microphone, backend or fake metrics. No autoplay. The subject is a real working pattern rather than decorative stock.

## Run

Python3: `python build.py` then `python -m http.server 8000`. Open localhost port 8000. No install, network or build dependencies. Edit src/pages, shared header/footer and fixture.json; build.py regenerates HTML and fixture.js. Edit app.js, synth.js and style.css directly. Do not regenerate with an older external scaffold.

## Product

48 keyboard-native step buttons, explicit play/stop,55 to 180 whole BPM, volume 0 to 70%, original presets, clear/one-level undo, actual WAV export. One bar of sixteenth notes in 4/4. Export contains one bar plus 0.3 second decay tail. Edits stop playback; browser-hidden state and navigation stop playback. Async audio-start cancellation protects against a changed pattern beginning unexpectedly. Session-only, no persistence. On narrow phones the grid recomposes into four rows of four per sound to retain 44px controls.

## Tests

Python Playwright and Chromium: `python tests/check_product.py`. Set CHROME_PATH when Chromium is elsewhere. Additional axe/audio-state test: `AXE_PATH=/path/to/axe.min.js python tests/check_audio_states.py`. Browser tests use temporary local port 8776 and write test-output (excluded from release). Tests require optional development dependencies, not dependencies for the website. See VALIDATION.md.

## Rights

Original source/text/patterns/sound under MIT. Manrope fonts have separate SIL OFL notice. All source and audio are bundled. No user research, account data, transcripts, borrowed brand or paid asset. ASSETS.json identifies roles and caveats.

## Limits

Live browser timers are not sample-accurate; WAV placement is sample-indexed. Do not present this as a DAW, safe listening certification or studio-quality claim. Actual listening, Safari, physical devices, screen readers, native coding-client installation and field-performance remain untested. This candidate is not a commercial service or evidence of universal agent compatibility. No public release is implied.
