from pathlib import Path
import json
r=Path(__file__).resolve().parent
f=json.loads((r/'fixture.json').read_text());names=['THUMP','CRACK','TICK']
pattern=''.join('<div class="preview-row"><span>'+names[n]+'</span><div>'+''.join('<b class="'+('on' if v else '')+'">'+str(i+1).zfill(2)+'</b>' for i,v in enumerate(track))+'</div></div>' for n,track in enumerate(f['tracks']))
(r/'fixture.js').write_text('window.INTERVAL_FIXTURE='+json.dumps(f)+';')
for key,title in json.loads((r/'src/titles.json').read_text()).items():
 body=(r/f'src/pages/{key}.html').read_text().replace('{{pattern}}',pattern)
 html='<!doctype html><html lang="en"><head><script>document.documentElement.classList.add("js")</script><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="description" content="An original local browser rhythm instrument. No account, microphone or uploads."><title>'+title+' | Interval</title><link rel="stylesheet" href="style.css"><script src="fixture.js" defer onerror="document.documentElement.classList.add(\'boot-failed\')"></script><script src="synth.js" defer onerror="document.documentElement.classList.add(\'boot-failed\')"></script><script src="app.js" defer onerror="document.documentElement.classList.add(\'boot-failed\')"></script></head><body>'+(r/'src/header.html').read_text()+'<main id="main">'+body+'</main>'+(r/'src/footer.html').read_text()+'</body></html>'
 (r/(key+'.html')).write_text(html)
print('Built five pages from shared source and one fixture')
