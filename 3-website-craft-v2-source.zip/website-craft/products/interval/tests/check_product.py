from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,wave,io,struct,os
r=Path(__file__).resolve().parents[1];o=r/'test-output';o.mkdir(exist_ok=True)
s=subprocess.Popen(['python','-m','http.server','8776','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.4);results=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox']);q=b.new_page()
  for w in [320,390,768,1024,1440]:
   q.set_viewport_size({'width':w,'height':1000})
   for route in ['index','instrument','sounds','guide','reality']:
    q.goto(f'http://localhost:8776/{route}.html');q.evaluate('document.fonts.ready');q.screenshot(path=str(o/f'{route}-{w}.png'),full_page=True);d=q.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,headings:document.querySelectorAll('h1').length,small:[...document.querySelectorAll('button,input')].filter(x=>x.getBoundingClientRect().width<44||x.getBoundingClientRect().height<44).map(x=>x.id||x.textContent)})''');assert not d['overflow'],(w,route,d);assert d['headings']==1;assert not d['small'],(w,route,d);results.append({'width':w,'route':route,**d})
  q.goto('http://localhost:8776/instrument.html');assert q.locator('.step').count()==48;start=q.locator('.step[aria-pressed=true]').count();q.locator('.step').first.click();assert q.locator('.step[aria-pressed=true]').count()==start-1;q.locator('#undo').click();assert q.locator('.step[aria-pressed=true]').count()==start
  q.locator('.step').first.focus();q.keyboard.press('ArrowLeft');assert q.locator('.step').nth(15).evaluate('(b)=>b===document.activeElement');q.keyboard.press('Home');assert q.locator('.step').first.evaluate('(b)=>b===document.activeElement')
  q.locator('#clear').click();assert q.locator('.step[aria-pressed=true]').count()==0;q.locator('#undo').click();assert q.locator('.step[aria-pressed=true]').count()==start
  q.locator('#bpm').fill('181');assert q.locator('#tempo-error').is_visible();q.locator('#bpm').fill('120');assert not q.locator('#tempo-error').is_visible()
  with q.expect_download() as d:q.locator('#export').click()
  path=d.value.path();raw=Path(path).read_bytes();f=wave.open(io.BytesIO(raw));assert f.getnchannels()==1 and f.getframerate()==44100 and f.getsampwidth()==2;assert abs(f.getnframes()/44100-2.3)<.0001;values=struct.unpack('<'+'h'*(len(raw[44:])//2),raw[44:]);assert max(values)>100;assert max(abs(v) for v in values)<32767
  q.locator('#play').click();q.wait_for_timeout(300);assert q.locator('body').evaluate('(b)=>b.classList.contains("playing")');q.locator('.step').first.click();assert not q.locator('body').evaluate('(b)=>b.classList.contains("playing")')
  q.locator('#play').click();q.wait_for_timeout(200);q.evaluate('''()=>{Object.defineProperty(document,'hidden',{configurable:true,value:true});document.dispatchEvent(new Event('visibilitychange'));}''');assert not q.locator('body').evaluate('(b)=>b.classList.contains("playing")')
  ctx=b.new_context();ctx.add_init_script('window.AudioContext=undefined;window.webkitAudioContext=undefined;');x=ctx.new_page();x.goto('http://localhost:8776/instrument.html');x.locator('#play').click();assert 'not available' in x.locator('#status').inner_text()
  with x.expect_download() as d:x.locator('#export').click()
  assert Path(d.value.path()).read_bytes()[:4]==b'RIFF';ctx.close()
  ctx=b.new_context(java_script_enabled=False);x=ctx.new_page();x.goto('http://localhost:8776/instrument.html');assert x.locator('noscript').is_visible();assert x.locator('#instrument').is_hidden();x.screenshot(path=str(o/'instrument-nojs.png'),full_page=True);ctx.close()
  b.close()
finally:s.terminate();s.wait()
(o/'checks.json').write_text(json.dumps(results,indent=2));print('25renders,48step editor,toggle/undo/clear,arrow/home,tempo validation,actual WAV header/length/nonzero samples,play+edit stop,visibility stop,unsupported audio+actual export,noJS passed')
