from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,json,wave,io,os
r=Path(__file__).resolve().parents[1];o=r/'test-output';o.mkdir(exist_ok=True);s=subprocess.Popen(['python','-m','http.server','8776','--directory',str(r)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(.3);audits=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox']);q=b.new_page()
  for route in ['index','instrument','sounds','guide','reality']:
   q.goto(f'http://localhost:8776/{route}.html');q.add_script_tag(path=os.environ['AXE_PATH']);a=q.evaluate('''async()=>{const a=await axe.run();return {violations:a.violations.map(v=>({id:v.id,impact:v.impact,nodes:v.nodes.map(n=>n.html)})),incomplete:a.incomplete.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.html)}))}}''');audits.append({'route':route,**a})
  q.goto('http://localhost:8776/instrument.html');full=q.evaluate('''()=>{const all=Array.from({length:3},()=>Array(16).fill(1));const a=IntervalSynth.mix(all,180,.7);return{max:Math.max(...a),min:Math.min(...a),same:IntervalSynth.mix(all,180,.7).every((x,i)=>x===a[i])}}''');assert full['max']<.98 and full['min']>-.98 and full['same'];print('full-density headroom/determinism',full)
  q.locator('#clear').click()
  with q.expect_download() as d:q.locator('#export').click()
  a=Path(d.value.path()).read_bytes();assert set(a[44:])=={0};assert 'silence' in q.locator('#export-status').inner_text()
  ctx=b.new_context();ctx.add_init_script('''class TestAudio {constructor(){this.state='suspended';this.sampleRate=44100;}async resume(){await new Promise(r=>setTimeout(r,200));this.state='running';}}window.AudioContext=TestAudio;''');x=ctx.new_page();x.goto('http://localhost:8776/instrument.html');x.locator('#play').click();x.locator('.step').first.click();x.wait_for_timeout(300);assert not x.locator('body').evaluate('(b)=>b.classList.contains("playing")');assert 'changed' in x.locator('#status').inner_text();ctx.close();print('delayed resume/edit cancellation passed')
  ctx=b.new_context(reduced_motion='reduce');x=ctx.new_page();x.goto('http://localhost:8776/instrument.html');x.locator('#play').click();x.wait_for_timeout(100);assert x.locator('.beat').first.evaluate('(b)=>getComputedStyle(b).boxShadow')=='none';x.locator('#play').click();ctx.close();print('reduced motion passed')
  b.close()
finally:s.terminate();s.wait()
(o/'axe.json').write_text(json.dumps(audits,indent=2));print(json.dumps(audits,indent=2))
