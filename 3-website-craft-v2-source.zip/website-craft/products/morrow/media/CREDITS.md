# Selected demonstration media
These photos illustrate a fictional farm-provisions example. They do not depict an actual Morrow supplier or prove any welfare, organic, stock or production claim. They retain Unsplash terms, not MIT. This is selected image use in an ordinary website example, not a photo corpus.

- eggs-erol-ahmed.jpg: Erol Ahmed, brown eggs in carton. https://unsplash.com/photos/brown-chicken-eggs-in-carton-leOh1CzRZVQ
- hens-brett-jordan.jpg: Brett Jordan, hens in a field. https://unsplash.com/photos/a-group-of-chickens-standing-on-top-of-a-lush-green-field-Q4cdkkJkv1Y
- gather-daniel-tuttle.jpg: Daniel Tuttle, hand with eggs by chickens. https://unsplash.com/photos/person-clutching-five-eggs-by-chickens-BPGPk_n7rkc

Source pages inspected 5 November 2026. All three say free under Unsplash License. Exact selected images inspected; no identifiable face/brand logo seen. https://unsplash.com/license . Do not sell unmodified photographs, compile a competing image collection or imply endorsement. Extra rights may apply to depicted people/property/marks; check intended new use.

Additional selected meal images used only for illustrative serving context, not product identity or supplier endorsement:
- roast-amanda-lim.jpg: Amanda Lim, sliced roast chicken. https://unsplash.com/photos/fried-chicken-on-black-tray--n0s7y7Nr2A
- breakfast-leti-kugler.jpg: Leti Kugler, egg on toast. https://unsplash.com/photos/sunny-side-up-egg-on-toasted-breads-I-ykyShydj0
Both original source pages inspected5Nov2026, free under Unsplash License. Actual frames inspected; no identifiable face/brand logo. The roast frame shows a partial hand; no identity claimed.

Fonts: Fraunces by the Fraunces Project Authors and Manrope by the Manrope Project Authors, SIL Open Font License1.1. Unmodified files served from Google Fonts; full notices in fonts/fraunces-OFL.txt and fonts/manrope-OFL.txt. Sources: https://github.com/google/fonts/blob/main/ofl/fraunces/OFL.txt and https://github.com/google/fonts/blob/main/ofl/manrope/OFL.txt . Do not relicense fonts as MIT.
