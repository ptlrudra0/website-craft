from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parents[1];out=root/'test-output';out.mkdir(exist_ok=True);server=subprocess.Popen(['python','-m','http.server','8768','--bind','127.0.0.1','--directory',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);r={}
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=__import__('os').environ.get('CHROME_PATH','/usr/bin/google-chrome'),headless=True,args=['--no-sandbox']);ctx=b.new_context(viewport={'width':390,'height':1000},permissions=['clipboard-read','clipboard-write']);page=ctx.new_page();base='http://127.0.0.1:8768/'
  page.goto(base+'enquiry.html');page.locator('#enquiry-form button[type=submit]').click();assert page.locator('#enquiry-result').is_hidden();r['empty_does_not_prepare']=True
  page.goto(base+'product-table-eggs.html');page.locator('input[name=quantity]').fill('0');page.locator('.add-form button').click();assert page.locator('[data-count]').inner_text()=='0';r['quantity_min_validation']=True
  page.locator('input[name=quantity]').fill('2');page.locator('.add-form button').click();page.goto(base+'enquiry.html');page.locator('#enquiry-form button[type=submit]').click();page.locator('[data-copy]').click();page.wait_for_function("document.querySelector('#copy-status').textContent.includes('No message has been sent')");assert 'x 2 packs' in page.evaluate('navigator.clipboard.readText()');r['clipboard_actual']=True
  with page.expect_download() as d:page.locator('[data-download]').click()
  d.value.save_as(str(out/'actual-enquiry-download.txt'));assert 'x 2 packs' in (out/'actual-enquiry-download.txt').read_text();r['download_actual']=True
  page.locator('textarea[name=notes]').fill('<img src=x onerror=alert(1)>');assert page.locator('#enquiry-result').is_hidden();page.locator('#enquiry-form button[type=submit]').click();assert '<img' in page.locator('#enquiry-text').input_value();assert page.locator('#enquiry-result img').count()==0;r['safe_text_not_html']=True
  page.locator('main .list-item input').fill('3');page.locator('main .list-item input').dispatch_event('change');assert page.locator('#enquiry-result').is_hidden();r['draft_invalidates_on_list_change']=True
  page.locator('#enquiry-form button[type=submit]').click();page2=ctx.new_page();page2.goto(base+'range.html');page2.locator('[data-quick-add]').first.click();page.wait_for_timeout(150);assert page.locator('#enquiry-result').is_hidden();r['cross_tab_invalidates']=True;page2.close()
  page.locator('.list-toggle').click();page.keyboard.press('Tab');focused=page.evaluate('document.activeElement.closest("dialog")!==null');assert focused;page.keyboard.press('Escape');assert page.evaluate('document.activeElement.classList.contains("list-toggle")');r['modal_focus_and_restore']=True
  page.goto(base+'supply.html');page.locator('input[name=volume]').fill('20 dozen');page.locator('#supply-form button').first.click();assert page.locator('#supply-result').is_visible();page.locator('input[name=volume]').fill('25 dozen');assert page.locator('#supply-result').is_hidden();r['trade_draft_invalidates']=True
  # Corrupted stored payload is rejected rather than interpolated into markup.
  page.evaluate('localStorage.setItem("website-craft-morrow-list-v1", JSON.stringify([{id:"unknown",pack:"x",qty:2},{id:"table-eggs",pack:"x",qty:-5}]))');page.reload();assert page.locator('[data-count]').inner_text()=='0';r['corrupt_storage_rejected']=True
  ctx.close();b.close()
finally:server.terminate();server.wait()
(out/'edge-checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
