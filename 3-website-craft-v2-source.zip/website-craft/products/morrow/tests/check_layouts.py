from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,json
root=Path(__file__).resolve().parents[1];out=root/'test-output';out.mkdir(exist_ok=True);server=subprocess.Popen(['python','-m','http.server','8768','--bind','127.0.0.1','--directory',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
checks=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=__import__('os').environ.get('CHROME_PATH','/usr/bin/google-chrome'),headless=True,args=['--no-sandbox'])
  for f in sorted(root.glob('*.html')):
   for w in [360,390,768,1024,1440]:
    page=b.new_page(viewport={'width':w,'height':1000},reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.goto('http://127.0.0.1:8768/'+f.name);page.wait_for_load_state('networkidle');page.evaluate("async()=>{document.querySelectorAll('img[loading=lazy]').forEach(i=>i.loading='eager');await Promise.all([...document.images].map(i=>i.decode().catch(()=>{})))}");page.screenshot(path=str(out/f'{f.stem}-{w}.png'),full_page=True)
    r=page.evaluate('''()=>({overflow:document.documentElement.scrollWidth>innerWidth,brokenImages:[...document.images].filter(x=>!x.naturalWidth).length,h1:document.querySelectorAll('h1').length,links:[...document.querySelectorAll('a')].map(x=>x.getAttribute('href'))})''');bad=[]
    for a in r.pop('links'):
     if a.startswith('#'):
      if len(a)>1 and not page.locator(a).count():bad.append(a)
     elif not a.startswith(('http','mailto:')) and not (root/a.split('#')[0]).resolve().exists():bad.append(a)
    checks.append({'page':f.name,'width':w,**r,'errors':errors,'badLinks':bad});page.close()
  page=b.new_page(viewport={'width':390,'height':900});page.goto('http://127.0.0.1:8768/product-table-eggs.html');page.locator('label').filter(has_text='30 eggs').click();page.locator('input[name=quantity]').fill('3');page.locator('.add-form button').click();assert page.locator('[data-count]').inner_text()=='3';page.locator('.list-toggle').click();assert page.locator('dialog').is_visible();assert '30 eggs' in page.locator('dialog').inner_text();page.keyboard.press('Escape');assert not page.locator('dialog').is_visible();page.goto('http://127.0.0.1:8768/enquiry.html');assert '30 eggs' in page.locator('main [data-list]').inner_text();page.locator('#enquiry-form button[type=submit]').click();assert '30 eggs x 3 packs' in page.locator('#enquiry-text').input_value();page.locator('[data-clear]').click();assert 'empty' in page.locator('main [data-list]').inner_text();page.goto('http://127.0.0.1:8768/range.html');page.locator('[data-filter=poultry]').click();assert page.locator('.catalogue .product-card:visible').count()==1;page.goto('http://127.0.0.1:8768/supply.html');page.locator('input[name=volume]').fill('20 dozen');page.locator('#supply-form button').first.click();assert '20 dozen' in page.locator('#supply-result').inner_text();page.locator('.menu-toggle').click();assert page.locator('nav').is_visible();page.keyboard.press('Escape');assert not page.locator('nav').is_visible();b.close()
finally:server.terminate();server.wait()
(out/'checks.json').write_text(json.dumps(checks,indent=2));print('renders',len(checks),'bad',[c for c in checks if c['overflow'] or c['brokenImages'] or c['errors'] or c['badLinks']]);print('interaction flow assertions passed')
