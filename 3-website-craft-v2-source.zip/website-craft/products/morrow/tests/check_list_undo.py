from pathlib import Path
from playwright.sync_api import sync_playwright
import subprocess,time,os,json
root=Path(__file__).resolve().parents[1];
out=root/'test-output';
out.mkdir(exist_ok=True);
server=subprocess.Popen(['python','-m','http.server','8791','--directory',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);
time.sleep(.3);
checks=[]
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),args=['--no-sandbox'])
  for width in [320,390,1024]:
   q=b.new_page(viewport={'width':width,'height':1000});
   q.goto('http://localhost:8791/product-table-eggs.html');
   q.locator('input[name=quantity]').fill('4');
   q.locator('.add-form button').click();
   q.goto('http://localhost:8791/enquiry.html');
   q.locator('#enquiry-form button[type=submit]').click();
   q.locator('[data-clear]').click();
   assert q.locator('#enquiry-result').is_hidden();
   assert not q.locator('#toast').evaluate('(x)=>x.classList.contains("show")');
   assert q.locator('main .list-undo button').evaluate('(x)=>x===document.activeElement');
   assert q.locator('main .list-item').count()==0;
   assert not q.evaluate('document.documentElement.scrollWidth>innerWidth');
   q.screenshot(path=str(out/f'clear-undo-{width}.png'),full_page=True);
   q.keyboard.press('Enter');
   assert q.locator('main .list-item input').input_value()=='4';
   assert q.locator('main .list-item input').evaluate('(x)=>x===document.activeElement');
   q.locator('.list-toggle').click();
   q.locator('dialog .remove').click();
   assert q.locator('dialog .list-item').count()==0;
   assert not q.locator('#toast').evaluate('(x)=>x.classList.contains("show")');
   q.locator('dialog .list-undo button').click();
   assert q.locator('dialog .list-item input').input_value()=='4';
   q.keyboard.press('Escape');
   q.reload();
   assert q.locator('main .list-item input').input_value()=='4';
   assert q.locator('.list-undo').count()==0;
   checks.append({'width':width,'clearRestore':True,'removeRestoreInDialog':True,'draftInvalidation':True,'focusRestore':True,'restoredListPersists':True,'undoSessionOnly':True});
   q.close()
  b.close()
finally:
 server.terminate()
 server.wait()
(out/'undo-checks.json').write_text(json.dumps(checks,indent=2));
print(json.dumps(checks,indent=2))
