from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,json
import os
root=Path(__file__).resolve().parents[1];out=root/'test-output';out.mkdir(exist_ok=True);server=subprocess.Popen(['python','-m','http.server','8768','--bind','127.0.0.1','--directory',str(root)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);r={}
try:
 with sync_playwright() as p:
  b=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH','/usr/bin/google-chrome'),headless=True,args=['--no-sandbox'])
  ctx=b.new_context(viewport={'width':390,'height':1000});ctx.add_init_script("Object.defineProperty(window,'localStorage',{get(){throw new Error('Storage disabled')}})");page=ctx.new_page();page.goto('http://127.0.0.1:8768/product-table-eggs.html');page.locator('.add-form button').click();assert page.locator('[data-count]').inner_text()=='1';assert 'may not save' in page.locator('#toast').inner_text();page.locator('.list-toggle').click();
  with page.expect_download() as dl:page.locator('[data-emergency-export]').click()
  dl.value.save_as(str(out/'storage-recovery-list.txt'));assert '12 eggs x 1' in (out/'storage-recovery-list.txt').read_text();r['storage_recovery_download']=True;
  page.screenshot(path=str(out/'storage-unavailable.png'));r['storage_unavailable_usable_in_page']=True
  ctx.close();ctx=b.new_context(viewport={'width':390,'height':1000});ctx.add_init_script("Object.defineProperty(navigator,'clipboard',{value:{writeText:()=>Promise.reject(new Error('denied'))}})");page=ctx.new_page();page.goto('http://127.0.0.1:8768/product-table-eggs.html');page.locator('.add-form button').click();page.goto('http://127.0.0.1:8768/enquiry.html');page.locator('#enquiry-form button[type=submit]').click();page.locator('[data-copy]').click();page.wait_for_function("document.querySelector('#copy-status').textContent.includes('unavailable')");assert page.locator('#enquiry-text').input_value();r['clipboard_failure_fallback']=True;ctx.close()
  ctx=b.new_context(viewport={'width':390,'height':1000},java_script_enabled=False);page=ctx.new_page();page.goto('http://127.0.0.1:8768/index.html');page.screenshot(path=str(out/'no-javascript-phone.png'));r['no_js_navigation_visible']=page.locator('nav').is_visible();ctx.close()
  ctx=b.new_context(viewport={'width':390,'height':1000});page=ctx.new_page();page.route('**/media/*.jpg',lambda route:route.abort());page.goto('http://127.0.0.1:8768/index.html');page.screenshot(path=str(out/'image-failure-phone.png'));r['image_fail_no_overflow']=page.evaluate('document.documentElement.scrollWidth<=innerWidth');ctx.close();b.close()
finally:server.terminate();server.wait()
(out/'failure-checks.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
