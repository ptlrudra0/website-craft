# Morrow / Field & Table

An original fictional farm-provisions specimen. 10 pages share a complete visual system and a browser-local enquiry journey. No supplier, current products/prices/stock, checkout or external message transmission exists. Selected photos illustrate, not substantiate business claims.

Run from this folder: `python -m http.server 8000 --bind 127.0.0.1`. Open the local URL in your browser. No keys or remote asset dependencies. Output HTML is committed for direct serving. To edit shared navigation/footer/drawer or page content, change src/ and run python build.py. Product cards and runtime selection data are generated from products.json; product-detail narrative remains page-specific in src/pages. Do not edit generated HTML or products.js.

Local list persists in this browser where storage is available; clear removes it. Planning forms need no contact details. Copy/download prepares a draft, not an order.

Test dependencies: Python Playwright and installed Chrome/Chromium. Set CHROME_PATH if not /usr/bin/google-chrome. Run `python tests/check_layouts.py` `python tests/check_journeys.py` and `python tests/check_failures.py`. They temporarily start a local server on port 8768. Ignored test-output/ stores evidence. These checks do not substitute for pixel inspection, real devices or native coding-agent tests.

Original code and illustration MIT. Photos retain Unsplash terms, fonts retain OFL 1.1. Read credits.html and included notices. Do not redistribute as a stock-photo corpus or imply a fictional supplier's origin/organic/welfare certification.

List removal/clear has a one-level Undo for the current page. A later quantity edit, add, external-tab change or reload discards that undo snapshot. Restoring a list does not restore a previously prepared enquiry: prepare it again.
